clc; clear; close all;

% ==== 1. Baca Citra ====
img = imread('church.png'); % ganti dengan file citra kamu
if size(img,3) == 3
    img_gray = rgb2gray(img);
else
    img_gray = img;
end

% ==== 2. Tambahkan Derau ====
img_sp_gray = imnoise(img_gray, 'salt & pepper', 0.05);
img_gauss_gray = imnoise(img_gray, 'gaussian', 0, 0.01);

img_sp_rgb = imnoise(img, 'salt & pepper', 0.05);
img_gauss_rgb = imnoise(img, 'gaussian', 0, 0.01);

% ==== 3. Definisikan Filter ====
w = 3; % ukuran filter
Q = 1.5; % untuk contraharmonic mean
d = 2;   % untuk alpha-trimmed

filters = {
    @(x) min(x(:)), 'Min Filter';
    @(x) max(x(:)), 'Max Filter';
    @(x) median(x(:)), 'Median Filter';
    @(x) mean(x(:)), 'Arithmetic Mean Filter';
    @(x) prod(double(x(:)).^(1/numel(x))), 'Geometric Mean Filter';
    @(x) numel(x)/sum(1./(double(x(:))+eps)), 'Harmonic Mean Filter';
    @(x) sum(double(x(:)).^(Q+1))/(sum(double(x(:)).^Q)+eps), 'Contraharmonic Mean Filter';
    @(x) (min(x(:)) + max(x(:)))/2, 'Midpoint Filter';
    @(x) mean(trim_values(double(x(:)), d)), 'Alpha-trimmed Mean Filter'
    };

% ==== 4. Proses untuk Citra Grayscale ====
disp('Memproses citra grayscale...');
for noise_type = ["Salt & Pepper", "Gaussian"]
    if noise_type == "Salt & Pepper"
        noisy = img_sp_gray;
    else
        noisy = img_gauss_gray;
    end
    
    figure('Name',['Grayscale dengan Derau ' char(noise_type)], 'NumberTitle','off');
    for k = 1:size(filters,1)
        f = filters{k,1};
        out = apply_filter(noisy, f, w);
        subplot(3,3,k);
        imshow(out, []);
        title(filters{k,2});
    end
    sgtitle(['Citra Grayscale - Derau ' char(noise_type)]);
end

% ==== 5. Proses untuk Citra RGB ====
disp('Memproses citra berwarna...');
for noise_type = ["Salt & Pepper", "Gaussian"]
    if noise_type == "Salt & Pepper"
        noisy = img_sp_rgb;
    else
        noisy = img_gauss_rgb;
    end
    
    figure('Name',['RGB dengan Derau ' char(noise_type)], 'NumberTitle','off');
    for k = 1:size(filters,1)
        f = filters{k,1};
        out_rgb = zeros(size(noisy));
        for c = 1:3 % proses tiap kanal warna
            out_rgb(:,:,c) = apply_filter(noisy(:,:,c), f, w);
        end
        out_rgb = uint8(out_rgb);
        subplot(3,3,k);
        imshow(out_rgb);
        title(filters{k,2});
    end
    sgtitle(['Citra RGB - Derau ' char(noise_type)]);
end

disp('Selesai! Semua hasil sudah ditampilkan.');

%% ==== Fungsi Pendukung ====
function out = apply_filter(img, func, w)
    img = double(img);
    pad = floor(w/2);
    [r,c] = size(img);
    out = zeros(r,c);
    img_pad = padarray(img, [pad pad], 'replicate');
    for i = 1:r
        for j = 1:c
            region = img_pad(i:i+w-1, j:j+w-1);
            out(i,j) = func(region);
        end
    end
    out = uint8(out);
end

function y = trim_values(x, d)
    x = sort(x);
    n = numel(x);
    d = min(d, n-2);
    y = x((d/2)+1 : n-(d/2));
end
