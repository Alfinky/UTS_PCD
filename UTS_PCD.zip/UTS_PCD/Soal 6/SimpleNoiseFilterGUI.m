function SimpleNoiseFilterGUI
    % === GUI UTAMA ===
    fig = figure('Name','Penghilangan Derau Periodik (Fourier Filter)',...
        'NumberTitle','off','Position',[300 200 900 500]);

    % === AXES UNTUK MENAMPILKAN CITRA ===
    ax1 = axes('Parent',fig,'Units','normalized','Position',[0.05 0.25 0.25 0.65]);
    title(ax1,'Citra Asli');
    ax2 = axes('Parent',fig,'Units','normalized','Position',[0.35 0.25 0.25 0.65]);
    title(ax2,'Spektrum Fourier');
    ax3 = axes('Parent',fig,'Units','normalized','Position',[0.65 0.25 0.25 0.65]);
    title(ax3,'Citra Setelah Filtering');

    % === TOMBOL-TOMBOL ===
    uicontrol('Style','pushbutton','String','1. Pilih Gambar',...
        'Units','normalized','Position',[0.1 0.08 0.2 0.1],...
        'FontSize',10,'Callback',@loadImage);

    uicontrol('Style','pushbutton','String','2. Proses & Hilangkan Derau',...
        'Units','normalized','Position',[0.4 0.08 0.25 0.1],...
        'FontSize',10,'Callback',@processImage);

    % === DATA SHARED ===
    imgData = struct('I',[],'axes1',ax1,'axes2',ax2,'axes3',ax3);
    guidata(fig, imgData);

    % === CALLBACK UNTUK MEMILIH GAMBAR ===
    function loadImage(~,~)
        [file, path] = uigetfile({'*.png;*.jpg;*.bmp','File Gambar'});
        if isequal(file,0)
            return;
        end
        I = imread(fullfile(path, file));
        imgData = guidata(fig);
        imgData.I = I;
        guidata(fig, imgData);
        axes(imgData.axes1);
        imshow(I,[]); title('Citra Asli');
    end

    % === CALLBACK UNTUK PROSES FILTERING ===
    function processImage(~,~)
        imgData = guidata(fig);
        if isempty(imgData.I)
            msgbox('Silakan pilih gambar terlebih dahulu!','Peringatan','warn');
            return;
        end

        I = imgData.I;
        if size(I,3)==3
            I = rgb2gray(I);
        end
        I = im2double(I);

        % --- Fourier Transform ---
        F = fftshift(fft2(I));
        S = log(1 + abs(F));

        % --- Deteksi titik terang (derau periodik) otomatis ---
        S_norm = mat2gray(S);
        level = graythresh(S_norm);
        BW = imbinarize(S_norm, level * 2);
        BW = bwareaopen(BW, 10);

        [rows, cols] = find(BW);
        [M, N] = size(I);
        center = [round(M/2), round(N/2)];
        dist_center = sqrt((rows - center(1)).^2 + (cols - center(2)).^2);
        mask = dist_center > 15; % abaikan pusat
        rows = rows(mask);
        cols = cols(mask);

        % --- Buat Notch Filter ---
        H = ones(M, N);
        radius = 5;
        for k = 1:length(rows)
            x = rows(k); y = cols(k);
            for i = 1:M
                for j = 1:N
                    if sqrt((i - x)^2 + (j - y)^2) <= radius
                        H(i,j) = 0;
                    end
                    xs = M - x + 1; ys = N - y + 1;
                    if sqrt((i - xs)^2 + (j - ys)^2) <= radius
                        H(i,j) = 0;
                    end
                end
            end
        end

        % --- Filtering & Inverse Fourier ---
        F_filtered = F .* H;
        I_filtered = real(ifft2(ifftshift(F_filtered)));

        % --- Tampilkan Hasil ---
        axes(imgData.axes2);
        imshow(S, []); title('Spektrum Fourier');

        axes(imgData.axes3);
        imshow(I_filtered, []); title('Citra Setelah Filtering');
    end
end
