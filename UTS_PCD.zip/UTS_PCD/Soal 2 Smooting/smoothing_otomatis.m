clc; clear; close all;

% === Daftar file gambar yang akan diuji ===
gambar_list = { ...
    'gedung_tua.jpg', ...
    'gedung_sate.jpg', ...
    'kapal_tua.jpg', ...
    'kupukupu.jpg', ...
    'saturnus.jpg', ...
    'planet.tif', ...
    'coins.png', ...
    'pemandangan.jpg'};

% === Membuat filter ===
mean_filter = fspecial('average', [3 3]);         % Mean filter 3x3
gaussian_filter = fspecial('gaussian', [7 7], 1); % Gaussian filter 7x7 (sigma = 1)

% === Looping semua gambar ===
for i = 1:length(gambar_list)
    nama_file = gambar_list{i};
    fprintf('\nMemproses gambar: %s\n', nama_file);

    try
        % --- Baca gambar ---
        info = imfinfo(nama_file);
        if numel(info) > 1
            img = imread(nama_file, 1); % ambil frame pertama jika multi-frame
        else
            img = imread(nama_file);
        end

        % --- Jika indexed (peta warna), ubah ke RGB ---
        if isfield(info, 'ColorType') && strcmpi(info.ColorType, 'indexed')
            img = ind2rgb(img, info.Colormap);
        end

        % --- Jika CMYK, ambil 3 channel pertama ---
        if size(img,3) == 4
            img = img(:,:,1:3);
        end

        % --- Ubah ke grayscale jika RGB ---
        if size(img,3) == 3
            img_gray = rgb2gray(img);
        else
            img_gray = img; % sudah grayscale
        end

        % --- Pastikan double [0,1] ---
        img_gray = im2double(img_gray);

        % --- Terapkan filter Mean dan Gaussian ---
        hasil_mean = imfilter(img_gray, mean_filter, 'replicate');
        hasil_gaussian = imfilter(img_gray, gaussian_filter, 'replicate');

        % --- Tampilkan hasil ---
        figure('Name', nama_file, 'NumberTitle', 'off');
        subplot(1,3,1); imshow(img_gray); title('Asli (Grayscale)');
        subplot(1,3,2); imshow(hasil_mean); title('Mean Filter');
        subplot(1,3,3); imshow(hasil_gaussian); title('Gaussian Filter');

    catch ME
        warning('❌ Gagal memproses %s: %s', nama_file, ME.message);
    end
end

disp('✅ Semua gambar berhasil diproses (yang valid).');
