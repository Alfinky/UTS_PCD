function uts_all_in_one_gui
% UTS_ALL_IN_ONE_GUI
% GUI tunggal untuk menyelesaikan soal-soal pengolahan citra tipe UTS
% (1..8) — filtering spasial, smoothing, edge detection, freq filtering,
% noise & denoise, morphological basics, motion blur + Wiener, blind.
%
% Simpan sebagai uts_all_in_one_gui.m lalu jalankan di MATLAB.
warning('off', 'MATLAB:imagesci:png:libraryWarning');

%% Create main figure
hFig = figure('Name','UTS Image Processing (Soal 1-8)', ...
    'NumberTitle','off','MenuBar','none','ToolBar','none',...
    'Position',[100 100 1200 700]);

% Left panel: controls
uipanel_ctrl = uipanel(hFig,'Title','Controls','FontSize',10,...
    'Position',[0.01 0.01 0.25 0.98]);

% Right: axes for images
ax_orig = axes(hFig,'Units','normalized','Position',[0.31 0.55 0.33 0.42]);
title(ax_orig,'Original / Input');
ax_proc = axes(hFig,'Units','normalized','Position',[0.66 0.55 0.33 0.42]);
title(ax_proc,'Processed / Output');

ax_aux1 = axes(hFig,'Units','normalized','Position',[0.31 0.05 0.33 0.42]);
title(ax_aux1,'Aux (e.g. PSF / Spectrum)');
ax_aux2 = axes(hFig,'Units','normalized','Position',[0.66 0.05 0.33 0.42]);
title(ax_aux2,'Aux 2');

%% Controls: choose soal/task
uicontrol(uipanel_ctrl,'Style','text','String','Pilih Soal / Task:',...
    'Units','normalized','Position',[0.05 0.92 0.9 0.05],'FontWeight','bold');

taskPopup = uicontrol(uipanel_ctrl,'Style','popupmenu', ...
    'String',{'1. Spatial Filtering (kernels)','2. Smoothing (mean/median/gauss)',...
    '3. Edge Detection (Sobel/Prewitt/Canny)','4. Freq-Domain Filtering (LP/HP)',...
    '5. Noise & Denoise (Gaussian / S&P)','6. Morphology (erosion/dilation)',...
    '7. Motion Blur + Wiener (manual)','8. Blind Deconvolution'},...
    'Units','normalized','Position',[0.05 0.86 0.9 0.05],'Callback',@taskChanged);

% Load image
uicontrol(uipanel_ctrl,'Style','text','String','Pilih gambar (file):','Units','normalized',...
    'Position',[0.05 0.78 0.9 0.04]);
btnLoad = uicontrol(uipanel_ctrl,'Style','pushbutton','String','Load Image','Units','normalized',...
    'Position',[0.05 0.73 0.9 0.05],'Callback',@onLoadImage);

% Show filename
txtFile = uicontrol(uipanel_ctrl,'Style','text','String','No file loaded','Units','normalized',...
    'Position',[0.05 0.68 0.9 0.04]);

% Parameter area (dynamic)
paramPanel = uipanel(uipanel_ctrl,'Title','Parameters','FontSize',9,...
    'Position',[0.05 0.12 0.9 0.54]);

% Run button
btnRun = uicontrol(uipanel_ctrl,'Style','pushbutton','String','Run Task','Units','normalized',...
    'Position',[0.05 0.04 0.9 0.06],'FontSize',11,'FontWeight','bold','Callback',@onRunTask);

% Data holders
data.img = [];
data.gray = [];
data.psf = [];
guidata(hFig,data);

% Initialize parameter UI for default task
taskChanged();

%% ---------------- Callback & helper functions ----------------
    function taskChanged(~,~)
        % Clear paramPanel and add appropriate controls per task
        taskIdx = get(taskPopup,'Value');
        delete(get(paramPanel,'Children'));
        switch taskIdx
            case 1 % Spatial Filtering
                uicontrol(paramPanel,'Style','text','String','Kernel (choose):',...
                    'Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                kPopup = uicontrol(paramPanel,'Style','popupmenu',...
                    'String',{'Sharpen','Box 3x3','Laplacian','Custom 3x3'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Custom kernel (comma sep 3x3 rows):',...
                    'Units','normalized','Position',[0.05 0.72 0.9 0.06]);
                editKernel = uicontrol(paramPanel,'Style','edit','String','0 -1 0; -1 5 -1; 0 -1 0',...
                    'Units','normalized','Position',[0.05 0.62 0.9 0.1]);
                uicontrol(paramPanel,'Style','text','String','Boundary option:','Units','normalized',...
                    'Position',[0.05 0.52 0.9 0.05]);
                bPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'replicate','symmetric','circular'},...
                    'Units','normalized','Position',[0.05 0.46 0.9 0.06]);
                % store handles
                set(paramPanel,'UserData',{kPopup,editKernel,bPopup});
                
            case 2 % Smoothing
                uicontrol(paramPanel,'Style','text','String','Method:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                sPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Mean 3x3','Median 3x3','Gaussian 5x5'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Gaussian sigma (if Gaussian):','Units','normalized',...
                    'Position',[0.05 0.72 0.9 0.06]);
                editSigma = uicontrol(paramPanel,'Style','edit','String','1.0','Units','normalized',...
                    'Position',[0.05 0.62 0.9 0.06]);
                set(paramPanel,'UserData',{sPopup,editSigma});
                
            case 3 % Edge Detection
                uicontrol(paramPanel,'Style','text','String','Method:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                ePopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Sobel','Prewitt','Canny'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Canny thresholds (low,high) (0-1):','Units','normalized',...
                    'Position',[0.05 0.72 0.9 0.06]);
                eThresh = uicontrol(paramPanel,'Style','edit','String','[0.1 0.3]','Units','normalized',...
                    'Position',[0.05 0.62 0.9 0.06]);
                set(paramPanel,'UserData',{ePopup,eThresh});
                
            case 4 % Frequency Filtering
                uicontrol(paramPanel,'Style','text','String','Filter type:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                fPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Ideal Lowpass','Gaussian Lowpass','Highpass (Butterworth approx)'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Cutoff (px):','Units','normalized','Position',[0.05 0.72 0.9 0.06]);
                fCut = uicontrol(paramPanel,'Style','edit','String','30','Units','normalized','Position',[0.05 0.62 0.9 0.06]);
                set(paramPanel,'UserData',{fPopup,fCut});
                
            case 5 % Noise & Denoise
                uicontrol(paramPanel,'Style','text','String','Noise type:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                nPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Gaussian','Salt&Pepper'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Noise param (sigma or density):','Units','normalized',...
                    'Position',[0.05 0.72 0.9 0.06]);
                nParam = uicontrol(paramPanel,'Style','edit','String','0.02','Units','normalized','Position',[0.05 0.62 0.9 0.06]);
                uicontrol(paramPanel,'Style','text','String','Denoise method:','Units','normalized','Position',[0.05 0.52 0.9 0.05]);
                dPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Wiener (filter2)','Median 3x3','Gaussian w/ imgaussfilt'},...
                    'Units','normalized','Position',[0.05 0.45 0.9 0.06]);
                set(paramPanel,'UserData',{nPopup,nParam,dPopup});
                
            case 6 % Morphology
                uicontrol(paramPanel,'Style','text','String','Operation:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                mPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Erode','Dilate','Open','Close'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Structuring element radius:',...
                    'Units','normalized','Position',[0.05 0.72 0.9 0.06]);
                mRadius = uicontrol(paramPanel,'Style','edit','String','2','Units','normalized','Position',[0.05 0.62 0.9 0.06]);
                set(paramPanel,'UserData',{mPopup,mRadius});
                
            case 7 % Motion Blur + Wiener
                uicontrol(paramPanel,'Style','text','String','Motion blur length (px):','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                mbLen = uicontrol(paramPanel,'Style','edit','String','20','Units','normalized','Position',[0.05 0.82 0.9 0.06]);
                uicontrol(paramPanel,'Style','text','String','Motion angle (deg):','Units','normalized','Position',[0.05 0.74 0.9 0.06]);
                mbAng = uicontrol(paramPanel,'Style','edit','String','30','Units','normalized','Position',[0.05 0.66 0.9 0.06]);
                uicontrol(paramPanel,'Style','text','String','Wiener K (0.001-0.1):','Units','normalized','Position',[0.05 0.58 0.9 0.06]);
                mbK = uicontrol(paramPanel,'Style','edit','String','0.01','Units','normalized','Position',[0.05 0.5 0.9 0.06]);
                set(paramPanel,'UserData',{mbLen,mbAng,mbK});
                
            case 8 % Blind Deconvolution
                uicontrol(paramPanel,'Style','text','String','Initial PSF type:','Units','normalized','Position',[0.05 0.9 0.9 0.08]);
                bPopup = uicontrol(paramPanel,'Style','popupmenu','String',{'Small Gaussian','Small Motion'},...
                    'Units','normalized','Position',[0.05 0.82 0.9 0.07]);
                uicontrol(paramPanel,'Style','text','String','Iterations (deconvblind):','Units','normalized','Position',[0.05 0.72 0.9 0.06]);
                bIter = uicontrol(paramPanel,'Style','edit','String','30','Units','normalized','Position',[0.05 0.62 0.9 0.06]);
                set(paramPanel,'UserData',{bPopup,bIter});
        end
    end

    function onLoadImage(~,~)
        [f,p] = uigetfile({'*.jpg;*.png;*.bmp;*.tif','Image Files'});
        if isequal(f,0)
            return;
        end
        fullname = fullfile(p,f);
        set(txtFile,'String',fullname);
        Iin = imread(fullname);
        data = guidata(hFig);
        data.img = Iin;
        if size(Iin,3)==3
            data.gray = im2double(rgb2gray(Iin));
        else
            data.gray = im2double(Iin);
        end
        guidata(hFig,data);
        axes(ax_orig); imshow(Iin); title('Original / Input');
        cla(ax_proc); cla(ax_aux1); cla(ax_aux2);
    end

    function onRunTask(~,~)
        data = guidata(hFig);
        if isempty(data) || isempty(data.img)
            errordlg('Please load an image first.','No Image');
            return;
        end
        I = data.gray;
        taskIdx = get(taskPopup,'Value');
        params = get(paramPanel,'UserData');
        % reset aux axes
        cla(ax_proc); cla(ax_aux1); cla(ax_aux2);
        switch taskIdx
            case 1 % Spatial filtering
                kPopup = params{1}; editKernel = params{2}; bPopup = params{3};
                sel = get(kPopup,'Value');
                bopt = get(bPopup,'Value'); bopts = {'replicate','symmetric','circular'}; bound = bopts{bopt};
                switch sel
                    case 1 % sharpen
                        K = [0 -1 0; -1 5 -1; 0 -1 0];
                    case 2 % box
                        K = fspecial('average',3);
                    case 3 % laplacian
                        K = fspecial('laplacian',0.2);
                    case 4 % custom
                        str = get(editKernel,'String');
                        try
                            K = str2num(str); %#ok<ST2NM>
                            if ~isequal(size(K),[3 3])
                                errordlg('Custom kernel must be 3x3');
                                return;
                            end
                        catch
                            errordlg('Invalid kernel string.');
                            return;
                        end
                end
                out = imfilter(I,K,'conv',bound);
                axes(ax_proc); imshow(out,[]); title('Spatial Filtered');
                axes(ax_aux1); imagesc(K); axis image off; title('Kernel');
                
            case 2 % Smoothing
                sPopup = params{1}; editSigma = params{2};
                sel = get(sPopup,'Value');
                switch sel
                    case 1
                        out = imfilter(I,fspecial('average',3),'replicate');
                    case 2
                        out = medfilt2(I,[3 3]);
                    case 3
                        sigma = str2double(get(editSigma,'String'));
                        out = imgaussfilt(I,sigma,'FilterSize',5);
                end
                axes(ax_proc); imshow(out,[]); title('Smoothed');
                
            case 3 % Edge detection
                ePopup = params{1}; eThresh = params{2};
                sel = get(ePopup,'Value');
                switch sel
                    case 1 % Sobel
                        out = edge(I,'sobel');
                    case 2 % Prewitt
                        out = edge(I,'prewitt');
                    case 3 % Canny
                        thr = str2num(get(eThresh,'String')); %#ok<ST2NM>
                        out = edge(I,'canny',thr);
                end
                axes(ax_proc); imshow(out); title('Edges');
                
            case 4 % Frequency domain filtering
                fPopup = params{1}; fCut = params{2};
                sel = get(fPopup,'Value'); cutoff = str2double(get(fCut,'String'));
                [M,N] = size(I);
                F = fftshift(fft2(I));
                [U,V] = meshgrid( (-floor(N/2)):(ceil(N/2)-1), (-floor(M/2)):(ceil(M/2)-1) );
                D = sqrt(U.^2 + V.^2);
                switch sel
                    case 1 % ideal lowpass
                        H = double(D <= cutoff);
                    case 2 % gaussian lowpass
                        H = exp(-(D.^2)/(2*cutoff^2));
                    case 3 % highpass (approx)
                        H = 1 - exp(-(D.^2)/(2*cutoff^2));
                end
                axes(ax_aux1); imagesc(log(1+abs(F))); axis image off; title('Spectrum (log)');
                axes(ax_aux2); imagesc(H); axis image off; title('Filter H');
                G = F .* H;
                out = real(ifft2(ifftshift(G)));
                axes(ax_proc); imshow(out,[]); title('Freq-Domain Filtered');
                
            case 5 % Noise & Denoise
                nPopup = params{1}; nParam = params{2}; dPopup = params{3};
                nsel = get(nPopup,'Value'); nval = str2double(get(nParam,'String'));
                % add noise
                switch nsel
                    case 1 % gaussian
                        noisy = imnoise(I,'gaussian',0,nval); % mean=0, var=nval
                    case 2 % s&p
                        noisy = imnoise(I,'salt & pepper',nval);
                end
                dsel = get(dPopup,'Value');
                switch dsel
                    case 1 % Wiener
                        out = wiener2(noisy,[5 5]);
                    case 2 % median
                        out = medfilt2(noisy,[3 3]);
                    case 3
                        out = imgaussfilt(noisy,1);
                end
                axes(ax_proc); imshow(out,[]); title('Denoised');
                axes(ax_aux1); imshow(noisy,[]); title('Noisy Input');
                
            case 6 % Morphology
                mPopup = params{1}; mRadius = params{2};
                msel = get(mPopup,'Value'); r = str2double(get(mRadius,'String'));
                se = strel('disk',max(1,round(r)));
                bw = imbinarize(I,graythresh(I));
                switch msel
                    case 1, out = imerode(bw,se);
                    case 2, out = imdilate(bw,se);
                    case 3, out = imopen(bw,se);
                    case 4, out = imclose(bw,se);
                end
                axes(ax_proc); imshow(out); title('Morphology Result (binary)');
                axes(ax_aux1); imshow(bw); title('Binary Input');
                
            case 7 % Motion Blur + Wiener (manual)
                mbLen = str2double(params{1}.String);
                mbAng = str2double(params{2}.String);
                mbK = str2double(params{3}.String);
                psf = fspecial('motion',max(1,round(mbLen)),mbAng);
                blurred = imfilter(I,psf,'conv','circular');
                restored = wiener_manual(I,psf,mbK); % apply deconv on observed I (if want to simulate blur then restore, use blurred)
                % show simulated blur + restore from that blurred image:
                restored_from_blur = wiener_manual(blurred,psf,mbK);
                axes(ax_aux1); imshow(psf,[]); title('PSF (motion)');
                axes(ax_orig); imshow(I); title('Original (Input)');
                axes(ax_proc); imshow(restored_from_blur,[]); title('Wiener restore (from simulated blur)');
                axes(ax_aux2); imshow(blurred,[]); title('Simulated Motion-Blur');
                
            case 8 % Blind deconvolution
                bPopup = params{1}; bIter = str2double(params{2}.String);
                if get(bPopup,'Value')==1
                    psf0 = fspecial('gaussian',9,2);
                else
                    psf0 = fspecial('motion',15,0);
                end
                try
                    [rest, psfest] = deconvblind(I, psf0, bIter);
                    axes(ax_proc); imshow(rest,[]); title('Blind Deconv Result');
                    axes(ax_aux1); imshow(psfest,[]); title('Estimated PSF');
                catch ME
                    errordlg(['deconvblind failed or unavailable: ' ME.message],'Error');
                end
        end
    end

%% ---------------- Utility internal functions ----------------
    function R = wiener_manual(Blur, PSF, K)
        % Manual Wiener deconvolution in freq domain
        if nargin<3, K=0.01; end
        [M,N] = size(Blur);
        H = psf2otf(PSF,[M N]);
        G = fft2(Blur);
        W = conj(H) ./ (abs(H).^2 + K);
        Fhat = W .* G;
        f = real(ifft2(Fhat));
        R = mat2gray(f);
    end

end
