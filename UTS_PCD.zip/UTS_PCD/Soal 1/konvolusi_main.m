clear; clc; close all;

% --- Load gambar contoh ---
img1 = imread('butterfly.png');        % grayscale
img2 = imread('snow1.png');            % berwarna
img3 = imread('snow2.png');            % berwarna

% Jika ada citra grayscale yang terbaca RGB
if size(img1,3)==3, img1 = rgb2gray(img1); end

% --- Definisikan kernel (contoh smoothing 3x3) ---
mask = [1 1 1; 1 1 1; 1 1 1] / 9;

% --- Konvolusi buatan ---
hasil1 = manual_conv(img1, mask);
hasil2 = manual_conv(img2, mask);
hasil3 = manual_conv(img3, mask);

% --- Konvolusi built-in MATLAB ---
builtin1 = imfilter(img1, mask);
builtin2 = imfilter(img2, mask);
builtin3 = imfilter(img3, mask);

% --- Tampilkan hasil ---
figure;
subplot(2,3,1); imshow(img1); title('Asli Grayscale');
subplot(2,3,2); imshow(hasil1); title('Manual Conv');
subplot(2,3,3); imshow(builtin1); title('MATLAB Conv');

subplot(2,3,4); imshow(img2); title('Asli Warna');
subplot(2,3,5); imshow(hasil2); title('Manual Conv');
subplot(2,3,6); imshow(builtin2); title('MATLAB Conv');
