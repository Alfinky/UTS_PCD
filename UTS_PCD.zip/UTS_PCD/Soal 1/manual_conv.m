function out = manual_conv(img, mask)

    [M,N,Ch] = size(img);            % ukuran citra
    [m,n] = size(mask);              % ukuran mask
    a = floor(m/2); b = floor(n/2);  % offset

    out = zeros(M,N,Ch);

    % loop channel (untuk grayscale & RGB)
    for c = 1:Ch
        for i = 1:M
            for j = 1:N
                sum = 0;
                for x = -a:a
                    for y = -b:b
                        ii = i + x;
                        jj = j + y;
                        if ii>=1 && ii<=M && jj>=1 && jj<=N
                            sum = sum + double(img(ii,jj,c)) * mask(x+a+1,y+b+1);
                        end
                    end
                end
                out(i,j,c) = sum;
            end
        end
    end

    out = uint8(out);
end
