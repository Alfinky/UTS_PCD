clc; clear; close all;

% --- Fungsi untuk membuat PSF motion blur ---
function psf = motion_blur_psf(len, theta)
    psf = zeros(len, len);
    center = floor(len/2) + 1;
    psf(center, :) = 1;
    psf = imrotate(psf, theta, 'bilinear', 'crop');
    psf = psf / sum(psf(:)); % normalisasi
end

% --- Fungsi untuk menerapkan motion blur ---
function blurred = apply_motion_blur(img, psf)
    blurred = imfilter(img, psf, 'conv', 'circular');
end

% --- Fungsi Wiener Filter buatan sendiri ---
function restored = wiener_filter_manual(blurred, psf, K)
    % FFT dari PSF dan citra blur
    [M, N, ~] = size(blurred);
    H = psf2otf(psf, [M, N]); % ubah PSF ke OTF (Optical Transfer Function)
    
    restored = zeros(size(blurred));
    for c = 1:size(blurred,3)
        G = fft2(blurred(:,:,c));
        H_conj = conj(H);
        F_hat = (H_conj ./ (abs(H).^2 + K)) .* G;
        f_hat = real(ifft2(F_hat));
        restored(:,:,c) = mat2gray(f_hat); % normalisasi hasil
    end
end

% ============================================================
% Bagian utama program
% ============================================================

% --- Ubah path gambar di bawah ke lokasi citra kamu ---
img1 = imread('grayscale_image.jpg');  % citra grayscale
img2 = imread('color_image.jpg');      % citra berwarna

% Jika citra pertama grayscale berwarna (RGB), ubah ke grayscale
if size(img1,3) == 3
    img1 = rgb2gray(img1);
end

% Parameter blur
len = 20;     % panjang motion blur
theta = 30;   % arah blur
K = 0.01;     % parameter Wiener (semakin kecil = lebih tajam tapi noisy)

% Buat PSF
psf = motion_blur_psf(len, theta);

% 1️⃣ Proses citra grayscale
blur_gray = apply_motion_blur(img1, psf);
restored_gray = wiener_filter_manual(blur_gray, psf, K);

figure;
subplot(1,3,1); imshow(img1); title('Asli (Grayscale)');
subplot(1,3,2); imshow(blur_gray); title('Setelah Motion Blur');
subplot(1,3,3); imshow(restored_gray); title('Hasil Wiener Filter');

% 2️⃣ Proses citra berwarna
blur_color = apply_motion_blur(img2, psf);
restored_color = wiener_filter_manual(blur_color, psf, K);

figure;
subplot(1,3,1); imshow(img2); title('Asli (Berwarna)');
subplot(1,3,2); imshow(blur_color); title('Setelah Motion Blur');
subplot(1,3,3); imshow(restored_color); title('Hasil Wiener Filter');

