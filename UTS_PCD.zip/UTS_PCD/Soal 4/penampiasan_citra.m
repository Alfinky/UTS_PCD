function homomorphic_gui_final

clc; close all;

% ==== LOAD IMAGE ====
I0 = imread('input.jpg');   % << ganti nama file gambar kamu
I  = im2double(I0);
if size(I,3)==3
    I = rgb2gray(I);
end

% ==== GUI WINDOW ====
figure('Position',[300 200 700 500],'Name','Homomorphic Filtering GUI');

subplot(1,2,1); imshow(I); title('Input image');
hAx = subplot(1,2,2); title('Filtered image (result)');

% ==== SLIDER gammaL ====
uicontrol('Style','text','Position',[50 445 150 20],...
          'String','gammaL (Brightness)');
s_gammaL = uicontrol('Style','slider','Position',[50 430 200 20],...
                     'Min',0.1,'Max',1.0,'Value',0.6);

% ==== SLIDER gammaH ====
uicontrol('Style','text','Position',[260 445 150 20],...
          'String','gammaH (Detail)');
s_gammaH = uicontrol('Style','slider','Position',[260 430 200 20],...
                     'Min',1.0,'Max',3.0,'Value',1.8);

% ==== SLIDER D0 ====
uicontrol('Style','text','Position',[470 445 150 20],...
          'String','Cutoff Frequency (D0)');
s_D0 = uicontrol('Style','slider','Position',[470 430 200 20],...
                 'Min',5,'Max',100,'Value',40);

% ==== BUTTON APPLY ====
uicontrol('Style','pushbutton','String','APPLY FILTER',...
          'Position',[300 385 120 30],...
          'Callback',@(~,~) applyFilter);

    function applyFilter(~,~)
        gammaL = s_gammaL.Value;
        gammaH = s_gammaH.Value;
        D0     = s_D0.Value;

        % ======== HOMOMORPHIC FILTERING ========
        Ilog = log(I + 1);
        F = fftshift(fft2(Ilog));
        [M,N] = size(I);
        [u,v] = meshgrid(-N/2:N/2-1, -M/2:M/2-1);
        D = sqrt(u.^2 + v.^2);

        H = (gammaH-gammaL) * (1 - exp(-(D.^2)/(2*D0^2))) + gammaL;

        G = H .* F;
        I2 = real(ifft2(ifftshift(G)));
        I2 = exp(I2) - 1;
        I2 = mat2gray(I2);

        imshow(I2,'Parent',hAx);
        title(hAx, sprintf('Filtered image (γL=%.2f  γH=%.2f  D0=%.0f)',gammaL,gammaH,D0));
    end

end
