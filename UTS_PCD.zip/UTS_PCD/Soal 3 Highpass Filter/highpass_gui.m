function highpass_gui

    % Buat Figure GUI (utama)
    fig = figure('Name','High-Pass Filter GUI', ...
        'NumberTitle','off','Units','normalized', ...
        'Position',[0.25 0.1 0.5 0.8], ... % proporsional di layar
        'Color','white');

    % Tombol pilih gambar
    uicontrol('Style','pushbutton','String','Pilih Gambar',...
        'Units','normalized','Position',[0.05 0.9 0.15 0.05],'FontSize',10, ...
        'Callback',@pilihGambar);

    % Tombol proses semua
    uicontrol('Style','pushbutton','String','Proses Semua Gambar',...
        'Units','normalized','Position',[0.25 0.9 0.2 0.05],'FontSize',10, ...
        'Callback',@prosesSemua);

    % Tombol keluar
    uicontrol('Style','pushbutton','String','Keluar',...
        'Units','normalized','Position',[0.85 0.9 0.1 0.05],'FontSize',10, ...
        'Callback',@(src,event) close(fig));

    % Slider untuk D0
    uicontrol('Style','text','String','Cutoff Frequency (D0):',...
        'Units','normalized','Position',[0.55 0.86 0.2 0.03],'BackgroundColor','white');
    txtD0 = uicontrol('Style','text','String','30',...
        'Units','normalized','Position',[0.75 0.86 0.05 0.03],'BackgroundColor','white');

    sliderD0 = uicontrol('Style','slider','Min',1,'Max',100,'Value',30,...
        'Units','normalized','Position',[0.55 0.82 0.25 0.03],'Callback',@ubahD0);

    % Axes untuk menampilkan gambar
    ax1 = axes('Parent',fig,'Units','normalized','Position',[0.05 0.45 0.35 0.35]);
    ax2 = axes('Parent',fig,'Units','normalized','Position',[0.45 0.55 0.25 0.25]);
    ax3 = axes('Parent',fig,'Units','normalized','Position',[0.75 0.55 0.2 0.25]);
    ax4 = axes('Parent',fig,'Units','normalized','Position',[0.55 0.25 0.25 0.25]);

    % Variabel global
    img = [];
    D0 = 30; % default cutoff

    % ===== Callback Functions =====
    function pilihGambar(~,~)
        [file, path] = uigetfile({'*.jpg;*.png;*.jpeg'},'Pilih Citra');
        if isequal(file,0), return; end
        img = imread(fullfile(path,file));
        updateTampilan();
        set(fig,'Name',['Hasil Filter: ',file]);
    end

    function ubahD0(~,~)
        D0 = round(get(sliderD0,'Value'));
        set(txtD0,'String',num2str(D0));
        if ~isempty(img)
            updateTampilan();
        end
    end

    function prosesSemua(~,~)
        folder = 'images';
        files = dir(fullfile(folder,'*.jpg'));
        if isempty(files)
            uialert(fig,'Tidak ada file gambar di folder "images"','Peringatan');
            return;
        end
        outputFolder = 'output';
        if ~exist(outputFolder,'dir')
            mkdir(outputFolder);
        end
        for k = 1:length(files)
            namaFile = files(k).name;
            img = imread(fullfile(folder,namaFile));
            hasil = applyFilters(img,D0);
            imwrite(hasil.ideal, fullfile(outputFolder,['ideal_',namaFile]));
            imwrite(hasil.gauss, fullfile(outputFolder,['gauss_',namaFile]));
            imwrite(hasil.butter, fullfile(outputFolder,['butter_',namaFile]));
        end
        uialert(fig,'Semua gambar telah diproses dan disimpan di folder "output"','Selesai');
    end

    % ===== Fungsi bantu utama =====
    function updateTampilan()
        hasil = applyFilters(img,D0);
        axes(ax1); imshow(img,[]); title('Citra Asli');
        axes(ax2); imshow(hasil.ideal,[]); title('Ideal HPF');
        axes(ax3); imshow(hasil.gauss,[]); title('Gaussian HPF');
        axes(ax4); imshow(hasil.butter,[]); title('Butterworth HPF');
    end

    % ===== Fungsi Filter =====
    function hasil = applyFilters(img,D0)
        if size(img,3)==3
            img_gray = rgb2gray(img);
        else
            img_gray = img;
        end
        img_gray = im2double(img_gray);
        [M,N] = size(img_gray);
        [U,V] = meshgrid(1:N,1:M);
        D = sqrt((U-N/2).^2 + (V-M/2).^2);

        % FFT
        F = fftshift(fft2(img_gray));

        % Ideal HPF
        H_ideal = double(D > D0);
        F_ideal = F .* H_ideal;
        ideal = mat2gray(real(ifft2(ifftshift(F_ideal))));

        % Gaussian HPF
        H_gauss = 1 - exp(-(D.^2) / (2*(D0^2)));
        F_gauss = F .* H_gauss;
        gauss = mat2gray(real(ifft2(ifftshift(F_gauss))));

        % Butterworth HPF
        n = 2;
        H_butter = 1 ./ (1 + (D0 ./ (D + eps)).^(2*n));
        F_butter = F .* H_butter;
        butter = mat2gray(real(ifft2(ifftshift(F_butter))));

        hasil.ideal = ideal;
        hasil.gauss = gauss;
        hasil.butter = butter;
    end
end
