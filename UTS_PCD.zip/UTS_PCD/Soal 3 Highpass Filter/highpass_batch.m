clc; clear; close all;

% === Folder tempat gambar ===
folder = 'images'; % folder berisi gambar uji
files = dir(fullfile(folder, '*.jpg')); % baca semua file .jpg
if isempty(files)
    error('Tidak ditemukan file gambar di folder "images".');
end

% === Parameter Filter ===
D0 = 50; % cutoff frequency
n = 2;   % orde untuk Butterworth

% === Proses Setiap Gambar ===
for k = 1:length(files)
    filename = fullfile(folder, files(k).name);
    img = imread(filename);
    fprintf('Memproses: %s\n', files(k).name);

    % === Konversi ke Grayscale ===
    if size(img,3) == 3
        img_gray = rgb2gray(img);
    else
        img_gray = img;
    end

    [M, N] = size(img_gray);
    F = fft2(double(img_gray));
    F_shift = fftshift(F);

    % === Buat koordinat frekuensi ===
    u = 0:(M-1);
    v = 0:(N-1);
    idx = find(u > M/2); u(idx) = u(idx) - M;
    idy = find(v > N/2); v(idy) = v(idy) - N;
    [V,U] = meshgrid(v,u);
    D = sqrt(U.^2 + V.^2);

    % === Filter Definitions ===
    H_ideal = double(D > D0);
    H_gauss = 1 - exp(-(D.^2) ./ (2*(D0^2)));
    H_butt  = 1 ./ (1 + (D0 ./ (D + eps)).^(2*n));

    % === Terapkan Filter ===
    G1 = H_ideal .* F_shift;
    G2 = H_gauss .* F_shift;
    G3 = H_butt  .* F_shift;

    % === Transformasi Balik ===
    g1 = real(ifft2(ifftshift(G1)));
    g2 = real(ifft2(ifftshift(G2)));
    g3 = real(ifft2(ifftshift(G3)));

    % === Tampilkan Hasil ===
    figure('Name',files(k).name, 'NumberTitle','off');
    subplot(2,2,1), imshow(img_gray, []), title('Citra Asli (Grayscale)');
    subplot(2,2,2), imshow(g1, []), title('Ideal HPF');
    subplot(2,2,3), imshow(g2, []), title('Gaussian HPF');
    subplot(2,2,4), imshow(g3, []), title('Butterworth HPF');
end

disp('=== Semua citra telah selesai diproses ===');
