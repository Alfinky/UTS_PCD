% =============================================================
% FINAL CODE : Motion/Gaussian Wiener + Fine-Tuning + Blind Deconvolution
% =============================================================

clc; clear; close all;

%% --- Baca citra blur ---
fname = 'girl_blur.png';  % <-- Ganti nama file dengan citra blur kamu
Iorig = imread(fname);
if size(Iorig,3)==3
    I = im2double(rgb2gray(Iorig));
else
    I = im2double(Iorig);
end

figure('Name','Input');
imshow(I); title('Citra Blur Input');

%% --- Fungsi Manual Wiener ---
function Rest = wiener_manual(Blur, PSF, K)
    if nargin < 3, K = 0.01; end
    [M,N] = size(Blur);
    H = psf2otf(PSF,[M N]);
    G = fft2(Blur);
    W = conj(H) ./ (abs(H).^2 + K);
    Fhat = W .* G;
    f = real(ifft2(Fhat));
    Rest = mat2gray(f);
end

%% --- Fungsi Sharpness Metric ---
function s = sharpness_metric(img)
    lap = fspecial('laplacian',0);
    L = imfilter(img, lap, 'replicate');
    s = var(L(:));
end

%% --- 1) Grid Search Model Motion ---
len_vals = [5 9 13 17 21 25];
angle_vals = [0 15 30 45 60 75 90];
K = 0.01;
best_score = -inf;
best_motion = struct('len',0,'angle',0,'rest',[],'psf',[]);

for L = len_vals
    for A = angle_vals
        psf = fspecial('motion', L, A);
        rec = wiener_manual(I, psf, K);
        score = sharpness_metric(rec);
        if score > best_score
            best_score = score;
            best_motion.len = L;
            best_motion.angle = A;
            best_motion.rest = rec;
            best_motion.psf = psf;
        end
    end
end
disp(['Best motion PSF: len=' num2str(best_motion.len) ...
      ', angle=' num2str(best_motion.angle) ...
      ', sharpness=' num2str(best_score,3)]);

%% --- 2) Grid Search Model Gaussian ---
sigma_vals = [0.5 1 1.5 2 3 4 5];
size_vals = [3 5 7 9 11];
best_score_g = -inf;
best_gauss = struct('sigma',0,'hsize',0,'rest',[],'psf',[]);

for s = sigma_vals
    for hs = size_vals
        if mod(hs,2)==0, continue; end
        psf = fspecial('gaussian', hs, s);
        rec = wiener_manual(I, psf, K);
        score = sharpness_metric(rec);
        if score > best_score_g
            best_score_g = score;
            best_gauss.sigma = s;
            best_gauss.hsize = hs;
            best_gauss.rest = rec;
            best_gauss.psf = psf;
        end
    end
end
disp(['Best gaussian PSF: size=' num2str(best_gauss.hsize) ...
      ', sigma=' num2str(best_gauss.sigma) ...
      ', sharpness=' num2str(best_score_g,3)]);

%% --- 3) Tampilkan Perbandingan Awal ---
figure('Name','Perbandingan Awal');
subplot(1,3,1); imshow(I); title('Input (Blur)');
subplot(1,3,2); imshow(best_motion.rest); 
title(sprintf('Wiener Motion (L=%d, A=%d)', best_motion.len, best_motion.angle));
subplot(1,3,3); imshow(best_gauss.rest);
title(sprintf('Wiener Gaussian (σ=%.2g, size=%d)', best_gauss.sigma, best_gauss.hsize));

%% --- 4) Fine-Tuning di sekitar PSF terbaik ---
disp('--- Fine-tuning di sekitar PSF terbaik ---');
use_motion = best_score > best_score_g;

if use_motion
    L_center = best_motion.len; A_center = best_motion.angle;
    len_range = max(1,L_center-4):min(40,L_center+4);
    angle_range = max(0,A_center-10):2:min(90,A_center+10);
    K = 0.005;
    fine_best_score = -inf; fine_best = struct;
    for L = len_range
        for A = angle_range
            psf = fspecial('motion', L, A);
            rec = wiener_manual(I, psf, K);
            score = sharpness_metric(rec);
            if score > fine_best_score
                fine_best_score = score;
                fine_best.len = L;
                fine_best.angle = A;
                fine_best.rest = rec;
                fine_best.psf = psf;
            end
        end
    end
    fprintf('Fine-tuned Motion: len=%d, angle=%d, sharpness=%.3f\n', ...
        fine_best.len, fine_best.angle, fine_best_score);
    figure; imshow(fine_best.rest);
    title(sprintf('Fine-tuned Motion (L=%d, A=%d)', fine_best.len, fine_best.angle));
else
    s_center = best_gauss.sigma; h_center = best_gauss.hsize;
    sigma_range = max(0.5,s_center-1):0.25:s_center+1;
    size_range = max(3,h_center-2):2:h_center+2;
    K = 0.005;
    fine_best_score = -inf; fine_best = struct;
    for s = sigma_range
        for hs = size_range
            psf = fspecial('gaussian', hs, s);
            rec = wiener_manual(I, psf, K);
            score = sharpness_metric(rec);
            if score > fine_best_score
                fine_best_score = score;
                fine_best.sigma = s;
                fine_best.hsize = hs;
                fine_best.rest = rec;
                fine_best.psf = psf;
            end
        end
    end
    fprintf('Fine-tuned Gaussian: size=%d, sigma=%.2f, sharpness=%.3f\n', ...
        fine_best.hsize, fine_best.sigma, fine_best_score);
    figure; imshow(fine_best.rest);
    title(sprintf('Fine-tuned Gaussian (σ=%.2f, size=%d)', ...
        fine_best.sigma, fine_best.hsize));
end

%% --- 5) Lucy-Richardson Refinement (opsional) ---
iter = 20;
try
    lucy_res = deconvlucy(I, fine_best.psf, iter);
    figure('Name','Lucy-Richardson Refinement');
    subplot(1,2,1); imshow(I); title('Input (Blur)');
    subplot(1,2,2); imshow(lucy_res);
    title(sprintf('Lucy-Richardson (%d iter)', iter));
catch
    disp('deconvlucy tidak tersedia, skip refinement.');
end

%% --- 6) Blind Deconvolution (tanpa PSF diketahui) ---
disp('--- Blind Deconvolution ---');
psf_init = fspecial('gaussian', 9, 2);
num_iter = 30;
[restored_blind, psf_est] = deconvblind(I, psf_init, num_iter);

figure('Name','Blind Deconvolution');
subplot(1,3,1); imshow(I); title('Input (Blur)');
subplot(1,3,2); imshow(restored_blind); title('Blind Deconvolution Result');
subplot(1,3,3); imshow(psf_est, []); title('PSF Estimasi');

disp('Blind deconvolution selesai.');
